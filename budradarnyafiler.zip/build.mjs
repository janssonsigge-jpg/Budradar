// Kompilerar src/*.jsx till platt, minifierad JS i js/.
// Körs manuellt efter ändringar i src/: npm run build
// (index.html laddar den kompilerade filen direkt — ingen Babel i webbläsaren.)

import * as esbuild from "esbuild";

await esbuild.build({
  entryPoints: ["src/index.jsx"],
  outfile: "js/index.js",
  bundle: false,
  minify: true,
  target: "es2019",
  jsxFactory: "React.createElement",
  jsxFragment: "React.Fragment",
  loader: { ".jsx": "jsx" },
});

console.log("Byggde js/index.js");
