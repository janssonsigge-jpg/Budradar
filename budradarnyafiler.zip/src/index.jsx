const { useState, useEffect, useMemo, useCallback } = React;

// Live-datakälla: samma adress som appen. Rank-fliken hämtar härifrån,
// faller tillbaka på DEMO om API:t inte svarar.
const API = "/api/companies";


// ---------- data ----------
const DEMO = [
  { ticker: "NETEL", name: "Netel Holding", list: "Nasdaq Sthlm", priceSEK: 22.1, mcapMSEK: 1100,
    score: { composite: 78, tier: "HÖG", parts: { insider: 88, flags: 90, shortSig: 32, bv: 50 } },
    detail: { insider: [{ person: "VD", tx_type: "Förvärv", amount_sek: 4200000, tx_date: "2026-05-26" },
                        { person: "Styrelseledamot", tx_type: "Förvärv", amount_sek: 1800000, tx_date: "2026-05-20" }],
      flags: [{ holder: "Aktivistfond X", threshold: "10%", direction: "upp", flag_date: "2026-05-27" },
              { holder: "Aktivistfond X", threshold: "5%", direction: "upp", flag_date: "2026-05-21" }],
      shorts: [{ holder: "Fond A", position_pct: 1.2, position_date: "2026-05-27" }],
      bolagsverket: [{ event_type: "Nytt bolag", note: "★ NewCo, samma c/o-adress som rådgivare", event_date: "2026-05-19" }] } },
  { ticker: "CINT", name: "Cint Group", list: "Nasdaq Sthlm", priceSEK: 9.7, mcapMSEK: 980,
    score: { composite: 64, tier: "MEDEL", parts: { insider: 50, flags: 20, shortSig: 43, bv: 50 } },
    detail: { insider: [{ person: "CFO", tx_type: "Förvärv", amount_sek: 900000, tx_date: "2026-05-24" }],
      flags: [{ holder: "PE-fond (via SPV)", threshold: "5%", direction: "upp", flag_date: "2026-05-20" }],
      shorts: [{ holder: "Fond B", position_pct: 0.6, position_date: "2026-05-24" }],
      bolagsverket: [{ event_type: "Nytt bolag", note: "★ Bidco-liknande SPV registrerad", event_date: "2026-05-23" }] } },
  { ticker: "VNV", name: "VNV Global", list: "Nasdaq Sthlm", priceSEK: 31.2, mcapMSEK: 2400,
    score: { composite: 61, tier: "MEDEL", parts: { insider: 72, flags: 35, shortSig: 63, bv: 15 } },
    detail: { insider: [{ person: "VD", tx_type: "Förvärv", amount_sek: 3100000, tx_date: "2026-05-28" }],
      flags: [{ holder: "Familjekontor Y", threshold: "10%", direction: "upp", flag_date: "2026-05-25" }],
      shorts: [{ holder: "Fond C", position_pct: 3.1, position_date: "2026-05-28" }], bolagsverket: [] } },
  { ticker: "APRTEC", name: "APR Technologies", list: "Spotlight", priceSEK: 15.5, mcapMSEK: 320,
    score: { composite: 41, tier: "MEDEL", parts: { insider: 47, flags: 35, shortSig: 0, bv: 15 } },
    detail: { insider: [{ person: "Grundare", tx_type: "Förvärv", amount_sek: 4200000, tx_date: "2026-05-22" }],
      flags: [{ holder: "Johan Claesson (bolag)", threshold: "10%", direction: "upp", flag_date: "2026-05-18" }],
      shorts: [], bolagsverket: [] } },
  { ticker: "SHOT", name: "Scandinavian Health", list: "First North", priceSEK: 44, mcapMSEK: 540,
    score: { composite: 8, tier: "LÅG", parts: { insider: 7, flags: 0, shortSig: 0, bv: 0 } },
    detail: { insider: [], flags: [], shorts: [], bolagsverket: [] } },
  { ticker: "BICO", name: "BICO Group", list: "Nasdaq Sthlm", priceSEK: 18.4, mcapMSEK: 1850,
    score: { composite: 6, tier: "LÅG", parts: { insider: 1, flags: 0, shortSig: 0, bv: 0 } },
    detail: { insider: [], flags: [], shorts: [], bolagsverket: [] } },
];

// Historik — riktiga svenska bud 2026 med verifierade siffror (premie mot senaste
// stängningskurs före offentliggörandet). Bidco = det nyregistrerade bolaget budet gick genom.
const HISTORIK = [
  { name: "Bahnhof", ticker: "BAHN", date: "2026-07-08", bidder: "Telenor", bidco: null,
    priceSEK: 62, mcapMSEK: null, premiumPct: 22, outcome: "Genomfört",
    signal: "Kontrollägare sålde", 
    note: "Grundarna Karlung och Norman sålde sitt innehav — 50,8 % av aktierna men 86 % av rösterna. När den som sitter på rösterna vill ut kan ingen stoppa affären." },
  { name: "Sleep Cycle", ticker: "SLEEP", date: "2026-05-11", bidder: "Altor Fund V", bidco: "Snark BidCo",
    priceSEK: 24.5, mcapMSEK: 1000, premiumPct: 47, outcome: "Genomfört",
    signal: "Nära 52v-lägsta",
    note: "Aktien handlades kring 15–16 kr, nära årslägsta, när budet kom på 24,50. Klassiskt mönster: budgivaren slår till när kursen är nedtryckt." },
  { name: "Nilörngruppen", ticker: "NIL B", date: "2026-05-04", bidder: "Trimco (Brookfield)", bidco: null,
    priceSEK: 77, mcapMSEK: 878, premiumPct: 53, outcome: "Genomfört",
    signal: "Storägare band sig",
    note: "Traction hade 26,3 % av kapitalet men 58,1 % av rösterna och band sig oåterkalleligen. Litet bolag (878 Mkr), låg värdering mot historiken." },
  { name: "Cint Group", ticker: "CINT", date: "2026-04-27", bidder: "Triton + Bolero", bidco: "TriCarbs BidCo",
    priceSEK: 6.0, mcapMSEK: 2000, premiumPct: 33, outcome: "Höjt bud",
    signal: "VD med i konsortiet",
    note: "VD Patrick Comer var själv del av budkonsortiet. Först 5,60 kr, höjt till 6,00 efter invändning. Mot 90-dagarssnittet var premien över 70 %." },
  { name: "Viva Wine Group", ticker: "VIVA", date: "2026-03-02", bidder: "Grundarna", bidco: "Riesling Ventures",
    priceSEK: 38.5, mcapMSEK: null, premiumPct: 38, outcome: "Genomfört",
    signal: "Grundarna köpte ut",
    note: "Grundarna tog hem bolaget via Riesling Ventures. Budet låg ändå under noteringskursen 49 kr — premie mäts mot kursen före budet, inte mot toppen." },
  { name: "Humana", ticker: "HUM", date: "2026-02-09", bidder: "Ambea", bidco: null,
    priceSEK: null, mcapMSEK: null, premiumPct: 27, outcome: "Genomfört",
    signal: "Branschkonsolidering",
    note: "Konkurrenten Ambea lade ett kombinerat kontant- och aktiebud. Industriell köpare snarare än private equity." },
  { name: "Biotage", ticker: "BIOT", date: "2026-01-12", bidder: "KKR", bidco: null,
    priceSEK: null, mcapMSEK: null, premiumPct: 60, outcome: "Genomfört",
    signal: "Utländsk PE-jätte",
    note: "Amerikanska KKR bjöd med ~60 % premie. Aktien steg över 55 % på veckan och blev börsens klart bästa." },
  { name: "Fortnox", ticker: "FNOX", date: "2025-06-16", bidder: "Hallrup + EQT", bidco: "First Kraft AB",
    priceSEK: 90, mcapMSEK: null, premiumPct: 38, outcome: "Genomfört",
    signal: "Storägare + PE",
    note: "2025 års största bud. Storägaren Olof Hallrup gick ihop med EQT för att ta hem bolaget." },
];

// ---------- app ----------

const C = { ink: "#0d1220", paper: "#f6f7fb", card: "#ffffff", line: "#e7e9f0",
  muted: "#6b7180", accent: "#3b4cff", accentSoft: "#eef0ff", green: "#1faa6c", red: "#d64545" };
const SERIF = "'Times New Roman', Times, Georgia, serif";
const SANS = "'Helvetica Neue', Helvetica, Arial, sans-serif";

// Lägg till dagar på ett datum (YYYY-MM-DD)
function addDays(dateStr, n) {
  const d = new Date(dateStr + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// Formatera börsvärde läsbart: 850 mkr / 12,4 mdkr
function fmtMcap(m) {
  if (m == null) return null;
  if (m >= 1000) return (m / 1000).toFixed(1).replace(".", ",") + " mdkr";
  return Math.round(m) + " mkr";
}

function BudRadar() {
  const [tab, setTab] = useState("rank");
  return (
    <div style={{ background: C.paper, minHeight: "100vh", fontFamily: SANS,
      backgroundImage: `linear-gradient(${C.line} 1px, transparent 1px), linear-gradient(90deg, ${C.line} 1px, transparent 1px)`,
      backgroundSize: "46px 46px" }}>
      <style>{CSS}</style>
      <div style={{ maxWidth: 480, margin: "0 auto", paddingBottom: 92, position: "relative", minHeight: "100vh" }}>
        {tab === "rank" && <RankTab />}
        {tab === "bidco" && <BidcoTab />}
        {tab === "historik" && <HistorikTab />}
        {tab === "lar" && <LarDigTab />}
        <BottomNav tab={tab} setTab={setTab} />
      </div>
    </div>
  );
}

/* ---------------- RANK ---------------- */
function RankTab() {
  const [filter, setFilter] = useState("ALLA");
  const [size, setSize] = useState("SMÅ"); // SMÅ = default; stora bolag blir sällan uppköpta
  const [query, setQuery] = useState("");
  const [sel, setSel] = useState(null);
  const [mounted, setMounted] = useState(false);
  const [data, setData] = useState(DEMO);
  const [status, setStatus] = useState("loading"); // loading | live | demo
  useEffect(() => { const t = setTimeout(() => setMounted(true), 60); return () => clearTimeout(t); }, []);
  const load = useCallback(async () => {
    setStatus("loading");
    try {
      const r = await fetch(API); if (!r.ok) throw 0;
      const j = await r.json();
      if (!j.companies || !j.companies.length) throw 0;
      // API-bolagen saknar detail-fältet i samma form → normalisera lätt
      setData(j.companies.map(c => ({ ...c, detail: c.detail || { insider: [], flags: [], shorts: [], bolagsverket: [] } })));
      setStatus("live");
    } catch { setData(DEMO); setStatus("demo"); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const rows = useMemo(() => {
    let d = [...data];
    // Sökning går före allt annat: söker du på ett bolag vill du hitta det
    // oavsett storleks- eller aktivitetsfilter.
    const q = query.trim().toLowerCase();
    if (q) {
      return d
        .filter((c) => (c.name || "").toLowerCase().includes(q) || (c.ticker || "").toLowerCase().includes(q))
        .sort((a, b) => b.score.composite - a.score.composite);
    }

    // HÅRT storleksfilter: bolag utan känt börsvärde döljs när filtret är på.
    // Anledningen: släpper vi igenom dem hamnar stora bolag (Intrum, H&M) i
    // toppen och hela listan tappar trovärdighet. Hellre kortare och rätt.
    if (size === "SMÅ") d = d.filter((c) => c.mcapMSEK != null && c.mcapMSEK <= 5000);
    if (size === "MEDEL") d = d.filter((c) => c.mcapMSEK != null && c.mcapMSEK <= 20000);
    if (filter !== "ALLA") d = d.filter((c) => c.score.tier === filter);
    return d.sort((a, b) => b.score.composite - a.score.composite);
  }, [filter, size, data, query]);
  const selCo = sel ? data.find((c) => c.ticker === sel) : null;
  const top = rows.length ? rows[0].score.composite : 0;
  const high = data.filter((c) => c.score.tier === "HÖG").length;
  const missingMcap = data.filter((c) => c.mcapMSEK == null).length;

  return (
    <>
      <nav style={s.nav}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <span style={s.brandDot} /><span style={{ fontWeight: 700, fontSize: 17, color: C.ink }}>BudRadar</span>
        </div>
        <div style={{ fontSize: 11, color: status==="live"?C.accent:C.muted, fontWeight: 700, letterSpacing: ".04em" }}>{status==="live"?"● live":status==="demo"?"demo":"…"}</div>
      </nav>

      <header style={{ position: "relative", padding: "36px 22px 26px", overflow: "hidden" }}>
        <div style={s.eyebrow}><span style={{ width: 7, height: 7, borderRadius: "50%", background: C.accent }} /> Signaler före budet</div>
        <h1 style={s.h1}>Vilka bolag kan bli <span style={{ fontStyle: "italic", color: C.accent }}>uppköpta?</span></h1>
        <p style={s.sub}>BudRadar bevakar de offentliga spåren ett uppköp lämnar — insynsköp, flaggningar, blankning — och rankar var det rör på sig. Ett spaningsverktyg, inte en garanti.</p>
        <div style={s.bidcoHint}>
          <span style={{ fontWeight: 700, color: C.ink }}>Ett tydligt spår:</span> budgivaren registrerar ofta ett nytt skalbolag först. Sleep Cycle köptes via <span style={{ color: C.accent, fontWeight: 600 }}>Snark Bidco</span>, Viva Wine via <span style={{ color: C.accent, fontWeight: 600 }}>Riesling Ventures</span>. Se fliken <span style={{ fontWeight: 600 }}>Bidco-spår</span>.
        </div>
        <div style={{ display: "flex", gap: 26, marginTop: 24 }}>
          <HeroStat n={data.length} l="bevakade bolag" />
          <HeroStat n={high} l="hög aktivitet" />
          <HeroStat n={top} l="högsta index" accent />
        </div>
        <div style={s.radar} aria-hidden><div style={s.ring} /><div style={s.ring2} /><div style={s.sweep} /><div style={s.blip} /></div>
      </header>

      <div style={{ padding: "4px 20px 10px", position: "relative" }}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Sök bolag eller ticker…"
          style={s.search}
        />
        {query && (
          <button onClick={() => setQuery("")} style={s.searchClear} aria-label="Rensa">×</button>
        )}
      </div>

      <div style={{ ...s.filterRow, paddingBottom: 4, opacity: query ? 0.4 : 1, pointerEvents: query ? "none" : "auto" }}>
        {[["SMÅ", "< 5 mdkr"], ["MEDEL", "< 20 mdkr"], ["ALLA", "Alla"]].map(([id, label]) => (
          <button key={id} className="pill" onClick={() => setSize(id)} style={pill(size === id)}>{label}</button>
        ))}
      </div>
      {!query && missingMcap > 0 && size !== "ALLA" && (
        <div style={{ padding: "0 20px 8px", fontSize: 11.5, color: C.muted, lineHeight: 1.45 }}>
          Visar {rows.length} av {data.length} bolag. {missingMcap} saknar börsvärde och döljs när storleksfiltret är på — välj Alla för att se dem.
        </div>
      )}
      <div style={{ ...s.filterRow, opacity: query ? 0.4 : 1, pointerEvents: query ? "none" : "auto" }}>
        {["ALLA", "HÖG", "MEDEL", "LÅG"].map((f) => (
          <button key={f} className="pill" onClick={() => setFilter(f)} style={pill(filter === f)}>{f}</button>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: "4px 18px" }}>
        {rows.map((c, i) => (
          <button key={c.ticker} className="card fadein" onClick={() => setSel(c.ticker)}
            style={{ ...s.co, animationDelay: `${Math.min(i, 8) * 45}ms` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 13 }}>
              <div style={s.rank}>{String(i + 1).padStart(2, "0")}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 17, letterSpacing: "-.01em", color: C.ink }}>{c.name}</div>
                <div style={s.meta}>{[c.ticker, c.priceSEK != null ? c.priceSEK + " kr" : null, c.mcapMSEK != null ? (c.mcapEstimated ? "~" : "") + fmtMcap(c.mcapMSEK) : null].filter(Boolean).join(" · ")}</div>
              </div>
              <Gauge v={c.score.composite} tier={c.score.tier} />
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 15 }}>
              {[["Insyn", c.score.parts.insider], ["Flagg", c.score.parts.flags], ["Short", c.score.parts.shortSig], ["Bolv", c.score.parts.bv]].map(([l, v]) => (
                <div key={l} style={{ flex: 1 }}>
                  <div style={s.track}><div style={{ ...s.fill, width: `${v}%`, background: v >= 60 ? C.accent : C.ink }} /></div>
                  <div style={s.sparkL}>{l}</div>
                </div>
              ))}
            </div>
          </button>
        ))}
        {!rows.length && <div style={{ textAlign: "center", padding: 40, color: C.muted, fontSize: 13 }}>Inga bolag i den här kategorin.</div>}
      </div>

      {selCo && <Sheet co={selCo} onClose={() => setSel(null)} />}
      <footer style={s.foot}>Endast offentlig data · ej investeringsrådgivning · indexet mäter aktivitet, inte sannolikhet för bud.</footer>
    </>
  );
}

function Sheet({ co, onClose }) {
  const d = co.detail;
  const [news, setNews] = useState(null);
  const [newsStatus, setNewsStatus] = useState("loading");
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await fetch("/api/news?company=" + encodeURIComponent(co.name) + "&limit=6");
        if (!r.ok) throw 0;
        const j = await r.json();
        if (!cancelled) { setNews(j.items || []); setNewsStatus("ok"); }
      } catch { if (!cancelled) setNewsStatus("error"); }
    })();
    return () => { cancelled = true; };
  }, [co.name]);
  return (
    <div style={s.overlay} onClick={onClose}>
      <div style={s.sheet} onClick={(e) => e.stopPropagation()}>
        <div style={s.grip} />
        <div style={s.sheetHead}>
          <div>
            <div style={{ fontFamily: SERIF, fontSize: 26, letterSpacing: "-.02em", color: C.ink }}>{co.name}</div>
            <div style={s.meta}>{[co.ticker, co.list, co.mcapMSEK != null ? co.mcapMSEK + " MSEK" : null].filter(Boolean).join(" · ")}</div>
          </div>
          <Gauge v={co.score.composite} tier={co.score.tier} />
        </div>
        <Sec title="Insynshandel · senaste">
          {!d.insider.length ? <Empty /> : d.insider.slice(0, 6).map((x, i) => (
            <Ev key={i} a={`${x.person} · ${x.tx_type}`} b={`${x.amount_sek ? (x.amount_sek / 1e6).toFixed(1) + " MSEK · " : ""}${x.tx_date || ""}`} />))}
        </Sec>
        <Sec title="Flaggningar">
          {!d.flags.length ? <Empty /> : d.flags.map((f, i) => (
            <Ev key={i}
              a={f.holder || f.label || "Flaggning"}
              b={[
                f.reason,
                f.threshold ? `passerade ${f.threshold}` : null,
                f.sharePct != null ? `→ ${f.sharePct}%` : null,
                f.flag_date,
              ].filter(Boolean).join(" · ")} />))}
        </Sec>
        <Sec title="Korta nettopositioner">
          {!d.shorts.length ? <Empty /> : <Grid items={[["Senaste", `${d.shorts[0].position_pct}%`], ["Datapunkter", d.shorts.length]]} />}
        </Sec>
        <Sec title="Pressmeddelanden">
          {newsStatus === "loading" && <div style={{ fontSize: 12, color: C.muted }}>Hämtar…</div>}
          {newsStatus === "error" && <div style={{ fontSize: 12, color: C.muted, fontStyle: "italic" }}>Kunde inte hämta flödet</div>}
          {newsStatus === "ok" && (!news || !news.length) && <Empty />}
          {newsStatus === "ok" && news && news.map((n, i) => (
            <a key={i} href={n.url || "#"} target="_blank" rel="noreferrer"
              style={{ display: "block", textDecoration: "none", padding: "7px 0", borderBottom: i < news.length - 1 ? `1px solid ${C.line}` : "none" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, color: C.ink, fontWeight: n.weight > 1 ? 700 : 500, lineHeight: 1.4 }}>{n.title}</div>
                  <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>{n.date}</div>
                </div>
                {n.tags && n.tags.length > 0 && (
                  <span style={{ ...s.signalTag, flexShrink: 0, fontSize: 9, padding: "2px 8px" }}>{n.tags[0]}</span>
                )}
              </div>
            </a>
          ))}
        </Sec>

        <Sec title="Bolagsverket">
          {!d.bolagsverket.length ? <Empty /> : d.bolagsverket.map((e, i) => (
            <Ev key={i} a={e.event_type} b={`${e.note} · ${e.event_date}`} />))}
        </Sec>
        <Sec title="Så räknas indexet">
          <p style={{ fontSize: 12, color: C.muted, lineHeight: 1.5, marginTop: -2, marginBottom: 12 }}>
            Ett vägt mått på hur mycket offentlig aktivitet som finns i bolaget just nu. Högt index = mycket händer — inte att ett bud är på väg.
          </p>
          {[["Insyn", co.score.parts.insider, "30%"], ["Flaggning", co.score.parts.flags, "30%"], ["Blankning", co.score.parts.shortSig, "20%"], ["Bolagsverket", co.score.parts.bv, "20%"]].map(([l, v, w]) => (
            <div key={l} style={{ display: "flex", alignItems: "center", gap: 11, padding: "5px 0" }}>
              <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: C.ink }}>{l} <span style={{ color: C.muted, fontSize: 11, fontWeight: 400 }}>{w}</span></span>
              <div style={{ flex: 1.4, height: 6, borderRadius: 999, background: "#eceef4", overflow: "hidden" }}>
                <div style={{ ...s.fill, width: `${v}%`, background: v >= 60 ? C.accent : C.ink }} /></div>
              <span style={{ width: 26, textAlign: "right", fontWeight: 700, fontSize: 14, color: C.ink }}>{v}</span>
            </div>))}
        </Sec>
        <button className="book" style={s.closeBtn} onClick={onClose}>Stäng</button>
      </div>
    </div>
  );
}

/* ---------------- HISTORIK ---------------- */
function HistorikTab() {
  const [view, setView] = useState("bud"); // bud | analys
  const done = HISTORIK.filter(h => h.premiumPct > 0);
  const avg = Math.round(done.reduce((s, h) => s + h.premiumPct, 0) / done.length);
  const withMcap = HISTORIK.filter(h => h.mcapMSEK);
  const medMcap = withMcap.length ? Math.round(withMcap.reduce((s,h)=>s+h.mcapMSEK,0)/withMcap.length) : null;

  // Registerdata från API:t (samma data som /api/registry)
  const [stats, setStats] = useState(null);
  const [statsStatus, setStatsStatus] = useState("idle");
  useEffect(() => {
    if (view !== "analys" || stats) return;
    setStatsStatus("loading");
    fetch("/api/registry?stats=1")
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(j => { setStats(j); setStatsStatus("ok"); })
      .catch(() => setStatsStatus("error"));
  }, [view, stats]);

  return (
    <>
      <SimpleHeader eyebrow="Avslutade bud" title={<>Vad hände <span style={{ fontStyle: "italic", color: C.accent }}>sen?</span></>}
        sub="Riktiga bud på svenska börsen — premien de gav och vad som gick att se i förväg." />
      <div style={{ display: "flex", gap: 24, padding: "0 22px 18px" }}>
        <HeroStat n={`+${avg}%`} l="snittpremie" accent />
        <HeroStat n={HISTORIK.length} l="bud i registret" />
        {medMcap && <HeroStat n={fmtMcap(medMcap)} l="snitt börsvärde" />}
      </div>

      <div style={{ ...s.filterRow, paddingBottom: 12 }}>
        {[["bud", "Buden"], ["analys", "Analys"]].map(([id, label]) => (
          <button key={id} className="pill" onClick={() => setView(id)} style={pill(view === id)}>{label}</button>
        ))}
      </div>

      {view === "analys" ? <RegistryAnalys stats={stats} status={statsStatus} /> : <>

      {/* MÖNSTERANALYS */}
      <div style={{ ...s.infoBox, margin: "0 18px 16px" }}>
        <b style={{ color: C.ink }}>Vad de har gemensamt</b>
        <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 7 }}>
          {[
            ["Små bolag", "Nilörn värderades till 878 Mkr, Cint till ~2 mdkr. Nästan inga bud sker över 5 mdkr."],
            ["Nedtryckt kurs", "Sleep Cycle låg nära 52-veckors lägsta. Budgivare slår till när aktien är billig, inte dyr."],
            ["Kontrollägaren vill ut", "Bahnhof: grundarna sålde. Nilörn: Traction band sig. Cint: VD var med i konsortiet."],
            ["Bidco registreras först", "Snark BidCo, TriCarbs BidCo, Riesling Ventures, First Kraft — skalet byggs innan budet."],
          ].map(([t, d]) => (
            <div key={t} style={{ display: "flex", gap: 9, alignItems: "flex-start" }}>
              <span style={{ color: C.accent, fontWeight: 700, fontSize: 13, lineHeight: 1.4 }}>·</span>
              <div><b style={{ color: C.ink, fontSize: 12.5 }}>{t}.</b> <span style={{ fontSize: 12.5 }}>{d}</span></div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: "4px 18px" }}>
        {HISTORIK.map((h, i) => {
          const drog = h.outcome === "Drogs tillbaka";
          return (
            <div key={i} style={s.co}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 13 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 16, color: C.ink }}>{h.name} <span style={{ color: C.muted, fontWeight: 400, fontSize: 12 }}>{h.ticker}</span></div>
                  <div style={s.meta}>{[h.date, h.bidder, h.priceSEK ? h.priceSEK + " kr" : null, fmtMcap(h.mcapMSEK)].filter(Boolean).join(" · ")}</div>
                  {h.bidco && <div style={{ ...s.meta, marginTop: 3, color: C.accent, fontWeight: 600 }}>via {h.bidco}</div>}
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
                  <div style={{ fontFamily: SERIF, fontSize: 28, lineHeight: .85, color: drog ? C.muted : C.green }}>
                    {h.premiumPct > 0 ? `+${h.premiumPct}%` : "—"}
                  </div>
                  <span style={outcomeTag(h.outcome)}>{h.outcome}</span>
                </div>
              </div>
              {h.signal && <div style={{ marginTop: 10 }}><span style={s.signalTag}>{h.signal}</span></div>}
              <p style={{ fontSize: 12.5, color: C.muted, lineHeight: 1.5, marginTop: 9 }}>{h.note}</p>
            </div>
          );
        })}
      </div>
      <div style={{ ...s.infoBox, margin: "14px 18px 0" }}>
        <b style={{ color: C.ink }}>Premie</b> = hur mycket budet ligger över kursen innan budet blev känt. Äger du aktien
        <i> före</i> budet får du skillnaden nästan direkt. Historiskt snitt på svenska börsen ligger kring 33 %.
      </div>
      </>}
      <footer style={s.foot}>Verifierade bud · premie mot senaste kurs före offentliggörandet · ej investeringsrådgivning.</footer>
    </>
  );
}

/* ---------------- LÄR DIG ---------------- */
const LEKTIONER = [
  { q: "Vad är BudRadar?",
    a: "BudRadar bevakar svenska börsbolag och letar efter tecken på att ett uppköp kan vara på väg. Appen läser bara offentlig information — sånt som vem som köper aktier, vem som passerar ägargränser och vilka nya bolag som registreras — och rankar bolagen efter hur många signaler som pekar åt samma håll. Ju högre score, desto fler samtidiga tecken." },
  { q: "Vad är ett uppköp (bud)?",
    a: "Ett uppköp är när någon — ett annat företag, en riskkapitalfond eller en storägare — vill köpa alla aktier i ett börsbolag. De lägger ett offentligt bud: 'vi betalar X kronor per aktie'. Om tillräckligt många ägare säger ja, tas bolaget över och försvinner ofta från börsen." },
  { q: "Så går det till, steg för steg",
    a: "1. Budgivaren bygger i tysthet en position och förbereder. 2. Ofta registreras ett nytt bolag (en 'bidco') som ska äga aktierna. 3. Budet offentliggörs — nästan alltid över gällande aktiekurs. 4. Ägarna accepterar eller inte. 5. Når budgivaren tillräcklig andel går affären igenom. Flera av de här stegen lämnar spår i offentliga register — och det är precis dem BudRadar fångar." },
  { q: "Varför tjänar man pengar på det?",
    a: "Ett bud läggs nästan alltid med en premie — ett pris klart över aktiekursen, ofta 20–40 % högre. Den som redan äger aktien när budet kommer ser kursen hoppa upp mot budnivån mer eller mindre direkt. Äger du för 100 kr och budet är 130 kr, är det +30 % i handen. Poängen med BudRadar är att hjälpa dig titta på bolag där tecknen hopar sig — innan budet blir allmänt känt." },
  { q: "Vad betyder signalerna?",
    a: "Insyn: bolagets egna chefer och styrelse köper aktier — de känner bolaget bäst. Flaggning: någon passerar en ägargräns (5/10/15 %), ofta ett tecken på att en köpare bygger position. Blankning: minskande blankning kan betyda att de som spekulerat i nedgång backar. Bolagsverket: en ny 'bidco' eller SPV kan vara skalet som ska genomföra ett köp." },
  { q: "Hur ska jag INTE använda den?",
    a: "BudRadar är inget facit och ingen investeringsrådgivning. En hög score betyder inte att ett bud kommer — bud är sällsynta och de flesta högt rankade bolag blir aldrig uppköpta. Scoren är en viktad signal, inte en sannolikhet, och den bygger på öppen data som redan är publik. Använd den som en uppslagslista för egen research, inte som en köpknapp." },
];

function LarDigTab() {
  const [open, setOpen] = useState(0);
  return (
    <>
      <SimpleHeader eyebrow="Lär dig" title={<>Så funkar det <span style={{ fontStyle: "italic", color: C.accent }}>egentligen</span></>}
        sub="Kort om uppköp, varför de gör dig pengar, och vad varje signal i appen faktiskt betyder." />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: "4px 18px" }}>
        {LEKTIONER.map((l, i) => {
          const isOpen = open === i;
          return (
            <div key={i} style={{ ...s.co, padding: 0, overflow: "hidden" }}>
              <button className="acc" onClick={() => setOpen(isOpen ? -1 : i)}
                style={{ width: "100%", textAlign: "left", background: "none", border: "none", cursor: "pointer",
                  padding: "16px 16px", display: "flex", alignItems: "center", gap: 12, fontFamily: SANS }}>
                <span style={{ fontFamily: SERIF, fontSize: 15, color: C.accent, width: 22 }}>{String(i + 1).padStart(2, "0")}</span>
                <span style={{ flex: 1, fontWeight: 700, fontSize: 15.5, color: C.ink }}>{l.q}</span>
                <span style={{ fontSize: 20, color: C.muted, transform: isOpen ? "rotate(45deg)" : "none", transition: "transform .2s" }}>+</span>
              </button>
              {isOpen && <p style={{ fontSize: 13.5, lineHeight: 1.6, color: C.muted, padding: "0 16px 18px 50px", margin: 0 }}>{l.a}</p>}
            </div>
          );
        })}
      </div>
      <div style={{ ...s.infoBox, margin: "14px 18px 0" }}>
        <b style={{ color: C.ink }}>Kom ihåg:</b> allt bygger på redan offentlig information. Det är lagligt att läsa och sammanställa
        publika register — det olagliga är att handla på information som <i>inte</i> är offentlig. BudRadar rör bara det förstnämnda.
      </div>
      <footer style={s.foot}>Utbildande material, ej investeringsrådgivning.</footer>
    </>
  );
}

/* ---------------- REGISTER-ANALYS ---------------- */
// Visar aggregerad statistik från /api/registry?stats=1 — alltså budregistret.
// Det här är den delen som är intressant för proffs: vilka premier betalas,
// av vem, och hur ägarbindningen såg ut före budet.
function RegistryAnalys({ stats, status }) {
  if (status === "loading") return <div style={{ padding: "0 20px", color: C.muted, fontSize: 13 }}>Hämtar registret…</div>;
  if (status === "error" || !stats) return (
    <div style={{ ...s.infoBox, margin: "0 18px" }}>
      Kunde inte hämta registret. Kontrollera att <code>/api/registry</code> är uppladdad.
    </div>
  );

  const p = stats.premie || {};
  const types = Object.entries(stats.perBudgivartyp || {}).sort((a, b) => (b[1].snittPremie ?? 0) - (a[1].snittPremie ?? 0));
  const sectors = Object.entries(stats.perBransch || {}).sort((a, b) => (b[1].snittPremie ?? 0) - (a[1].snittPremie ?? 0));
  const maxPrem = Math.max(...types.map(([, v]) => v.snittPremie ?? 0), 1);

  return (
    <div style={{ padding: "0 18px" }}>
      {/* Premiespann */}
      <div style={{ ...s.co, cursor: "default", marginBottom: 12 }}>
        <div style={s.secT}>Premie · alla bud i registret</div>
        <div style={{ display: "flex", gap: 22, marginTop: 4 }}>
          <div><div style={{ fontFamily: SERIF, fontSize: 30, color: C.accent, lineHeight: 1 }}>{p.snitt ?? "—"}%</div>
            <div style={{ fontSize: 10.5, color: C.muted, marginTop: 4 }}>snitt</div></div>
          <div><div style={{ fontFamily: SERIF, fontSize: 30, color: C.ink, lineHeight: 1 }}>{p.median ?? "—"}%</div>
            <div style={{ fontSize: 10.5, color: C.muted, marginTop: 4 }}>median</div></div>
          <div><div style={{ fontFamily: SERIF, fontSize: 30, color: C.ink, lineHeight: 1 }}>{p.lägsta ?? "—"}–{p.högsta ?? "—"}%</div>
            <div style={{ fontSize: 10.5, color: C.muted, marginTop: 4 }}>spann</div></div>
        </div>
      </div>

      {/* Premie per budgivartyp — den mest säljbara insikten */}
      <div style={{ ...s.co, cursor: "default", marginBottom: 12 }}>
        <div style={s.secT}>Snittpremie per budgivartyp</div>
        {types.map(([type, v]) => (
          <div key={type} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0" }}>
            <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: C.ink }}>{type}
              <span style={{ color: C.muted, fontWeight: 400, fontSize: 11 }}> · {v.antal} st</span></span>
            <div style={{ flex: 1.2, height: 7, borderRadius: 999, background: "#eceef4", overflow: "hidden" }}>
              <div style={{ height: "100%", borderRadius: 999, background: C.accent, width: `${((v.snittPremie ?? 0) / maxPrem) * 100}%` }} />
            </div>
            <span style={{ width: 44, textAlign: "right", fontWeight: 700, fontSize: 14, color: C.ink }}>{v.snittPremie ?? "—"}%</span>
          </div>
        ))}
        <p style={{ fontSize: 11.5, color: C.muted, lineHeight: 1.5, marginTop: 8 }}>
          Riskkapital betalar systematiskt högre premie än industriella köpare — de räknar på
          en exit, inte på synergier.
        </p>
      </div>

      {/* Bransch */}
      <div style={{ ...s.co, cursor: "default", marginBottom: 12 }}>
        <div style={s.secT}>Per bransch</div>
        {sectors.slice(0, 8).map(([sec, v]) => (
          <div key={sec} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", fontSize: 13 }}>
            <span style={{ color: C.ink }}>{sec}</span>
            <span style={{ color: C.muted }}>{v.antal} st · <b style={{ color: C.ink }}>{v.snittPremie ?? "—"}%</b></span>
          </div>
        ))}
      </div>

      {/* Bidco-tidsgap — den unika datapunkten */}
      {stats.bidcoTiming && stats.bidcoTiming.n > 0 && (
        <div style={{ ...s.co, cursor: "default", marginBottom: 12, borderColor: "#d9ddff" }}>
          <div style={s.secT}>Bidco → bud · tidsgap</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 9, marginTop: 2 }}>
            <span style={{ fontFamily: SERIF, fontSize: 40, color: C.accent, lineHeight: .9 }}>{stats.bidcoTiming.medianDagar}</span>
            <span style={{ fontSize: 13, fontWeight: 600 }}>dagars median</span>
          </div>
          <p style={{ fontSize: 12.5, color: C.muted, lineHeight: 1.55, marginTop: 9 }}>
            Tiden mellan att budgivaren registrerar sitt skalbolag och att budet offentliggörs.
            Spann {stats.bidcoTiming.kortast}–{stats.bidcoTiming.längst} dagar.
            {" "}{stats.bidcoTiming.andelInom30Dagar}% skedde inom 30 dagar.
          </p>
          <p style={{ fontSize: 11.5, color: C.muted, marginTop: 8, fontStyle: "italic" }}>
            {stats.bidcoTiming.osäkerhet || `Bygger på ${stats.bidcoTiming.n} observationer.`}
          </p>
        </div>
      )}

      {/* Bidco */}
      {stats.bidco && (
        <div style={{ ...s.co, cursor: "default", marginBottom: 12 }}>
          <div style={s.secT}>Bidco-strukturer</div>
          <div style={{ fontSize: 13, color: C.ink, marginBottom: 8 }}>
            <b style={{ fontFamily: SERIF, fontSize: 24, color: C.accent }}>{stats.bidco.andelMedKändBidco}%</b>
            <span style={{ color: C.muted, fontSize: 12 }}> av affärerna har känd bidco-kedja</span>
          </div>
          {(stats.bidco.exempel || []).map((b, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", fontSize: 12.5 }}>
              <span style={{ color: C.muted }}>{b.target}</span>
              <span style={{ color: C.accent, fontWeight: 600 }}>{b.bidco}</span>
            </div>
          ))}
        </div>
      )}

      {/* Ägarbindning */}
      {stats.ägarbindning && stats.ägarbindning.antalMedData > 0 && (
        <div style={{ ...s.infoBox, marginBottom: 12 }}>
          <b style={{ color: C.ink }}>Ägarbindning före budet.</b> I snitt hade{" "}
          <b style={{ color: C.accent }}>{stats.ägarbindning.snittBundenRöstandel}%</b> av rösterna
          bundit sig innan budet offentliggjordes. {stats.ägarbindning.kommentar}
        </div>
      )}

      <div style={{ fontSize: 11, color: C.muted, textAlign: "center", padding: "4px 0 0", lineHeight: 1.5 }}>
        Bygger på {stats.n} bud i registret. Fyll på <code>_registry-data.js</code> för starkare underlag.
      </div>
    </div>
  );
}

/* ---------------- BIDCO-SPÅR ---------------- */
function BidcoTab() {
  const [items, setItems] = useState([]);
  const [timing, setTiming] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | live | empty | error
  const load = useCallback(async () => {
    setStatus("loading");
    try {
      const r = await fetch("/api/bidco");
      if (!r.ok) throw 0;
      const j = await r.json();
      setItems(j.items || []);
      setTiming(j.timing || null);
      setStatus((j.items && j.items.length) ? "live" : "empty");
    } catch { setStatus("error"); }
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <>
      <SimpleHeader eyebrow="Nya bolagsskal" title={<>Vem bygger ett <span style={{ fontStyle: "italic", color: C.accent }}>bidco?</span></>}
        sub="Ett bidco (eller lagerbolaget 'Goldcup NNNN AB') är skalet ett uppköp genomförs genom. Dyker det upp i pressflödet kan ett bud vara nära." />

      {timing && timing.n > 0 && (
        <div style={{ ...s.co, cursor: "default", margin: "0 18px 12px" }}>
          <div style={s.secT}>Historiskt försprång</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginTop: 2 }}>
            <span style={{ fontFamily: SERIF, fontSize: 44, color: C.accent, lineHeight: .9 }}>{timing.medianDagar}</span>
            <span style={{ fontSize: 14, color: C.ink, fontWeight: 600 }}>dagar</span>
          </div>
          <p style={{ fontSize: 13, color: C.muted, lineHeight: 1.55, marginTop: 10 }}>
            Så lång tid gick i median mellan att skalbolaget registrerades och att budet blev offentligt.
            Spann {timing.kortast}–{timing.längst} dagar.
          </p>
          {timing.osäkerhet && (
            <p style={{ fontSize: 11.5, color: C.muted, marginTop: 8, fontStyle: "italic" }}>{timing.osäkerhet}</p>
          )}
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: "4px 18px" }}>
        {status === "loading" && <div style={{ ...s.co, cursor: "default" }}><div style={{ height: 15, background: "#eceef4", borderRadius: 8, width: "60%" }} /></div>}
        {status === "error" && <div style={{ ...s.infoBox }}>Kunde inte hämta pressflödet just nu. <button onClick={load} style={s.linkBtn}>Försök igen</button></div>}
        {status === "empty" && <div style={{ ...s.infoBox }}>Inga bidco-omnämnanden i det senaste flödet. Det är normalt — bud är sällsynta. Kolla igen om några dagar.</div>}
        {status === "live" && items.map((it, i) => (
          <a key={i} href={it.url || "#"} target="_blank" rel="noreferrer" className="card"
            style={{ ...s.co, textDecoration: "none", display: "block" }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 16, color: C.ink }}>{it.bidco}</div>
                {it.issuer && <div style={s.meta}>Kopplat till: {it.issuer}</div>}
                {!it.isOffer && timing && it.date && (
                  <div style={{ ...s.meta, marginTop: 4, color: C.accent, fontWeight: 600 }}>
                    Bud väntas omkring {addDays(it.date, timing.medianDagar)}
                  </div>
                )}
                <div style={{ ...s.meta, marginTop: 4 }}>{it.date || ""}</div>
              </div>
              {it.isOffer && <span style={{ ...s.chipOffer }}>BUD</span>}
            </div>
            <p style={{ fontSize: 12.5, color: C.muted, lineHeight: 1.5, marginTop: 10 }}>{it.title}</p>
          </a>
        ))}
      </div>
      <div style={{ ...s.infoBox, margin: "14px 18px 0" }}>
        <b style={{ color: C.ink }}>Så funkar spåret:</b> vi skannar färska marknadsmeddelanden efter bolagsnamn som slutar på
        <i> bidco/holdco</i> eller heter <i>Goldcup NNNN AB</i> — mönstret budgivare använder. Ett omnämnande betyder inte att
        ett bud är säkert, men det är ofta första spåret. (Cint-budet gick genom "Goldcup 39518 AB".)
      </div>
      <footer style={s.foot}>Skannar offentliga pressmeddelanden · ej investeringsrådgivning.</footer>
    </>
  );
}

/* ---------------- delade komponenter ---------------- */
function BottomNav({ tab, setTab }) {
  const items = [
    { id: "rank", label: "Rank", icon: IconRadar },
    { id: "bidco", label: "Bidco-spår", icon: IconTarget },
    { id: "historik", label: "Historik", icon: IconClock },
    { id: "lar", label: "Lär dig", icon: IconBook },
  ];
  return (
    <div style={s.bottomWrap}>
      <div style={s.bottomNav}>
        {items.map((it) => {
          const active = tab === it.id;
          const Icon = it.icon;
          return (
            <button key={it.id} onClick={() => setTab(it.id)} className="pill"
              style={{ flex: 1, background: "none", border: "none", cursor: "pointer", fontFamily: SANS,
                display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "4px 0" }}>
              <Icon color={active ? C.accent : C.muted} />
              <span style={{ fontSize: 11, fontWeight: active ? 700 : 500, color: active ? C.ink : C.muted, letterSpacing: ".02em" }}>{it.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
const IconRadar = ({ color }) => (  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
    <circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /><path d="M12 12 L19 7" /></svg>
);
const IconClock = ({ color }) => (
  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
    <circle cx="12" cy="12" r="9" /><path d="M12 7 v5 l3 2" /></svg>
);
const IconBook = ({ color }) => (
  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 5 a2 2 0 0 1 2-2 h5 v16 h-5 a2 2 0 0 0-2 2 z" /><path d="M20 5 a2 2 0 0 0-2-2 h-5 v16 h5 a2 2 0 0 1 2 2 z" /></svg>
);
const IconTarget = ({ color }) => (
  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
    <circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="3.5" /><path d="M12 2 v3 M12 19 v3 M2 12 h3 M19 12 h3" /></svg>
);

function SimpleHeader({ eyebrow, title, sub }) {
  return (
    <>
      <nav style={s.nav}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <span style={s.brandDot} /><span style={{ fontWeight: 700, fontSize: 17, color: C.ink }}>BudRadar</span>
        </div>
      </nav>
      <header style={{ padding: "34px 22px 18px" }}>
        <div style={s.eyebrow}><span style={{ width: 7, height: 7, borderRadius: "50%", background: C.accent }} /> {eyebrow}</div>
        <h1 style={{ ...s.h1, fontSize: 40, marginTop: 18 }}>{title}</h1>
        <p style={s.sub}>{sub}</p>
      </header>
    </>
  );
}
function Gauge({ v, tier }) {
  const hot = tier === "HÖG";
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
      <div style={{ fontFamily: SERIF, fontSize: 34, lineHeight: .85, letterSpacing: "-.02em", color: hot ? C.accent : C.ink }}>{v}</div>
      <span style={tag(tier)}>{tier}</span>
    </div>
  );
}
const HeroStat = ({ n, l, accent }) => (
  <div style={{ display: "flex", flexDirection: "column" }}>
    <div style={{ fontFamily: SERIF, fontSize: 30, lineHeight: 1, color: accent ? C.accent : C.ink }}>{n}</div>
    <div style={{ fontSize: 11, color: C.muted, marginTop: 5, letterSpacing: ".02em" }}>{l}</div>
  </div>
);
const Sec = ({ title, children }) => (
  <div style={{ borderBottom: `1px solid ${C.line}`, padding: "15px 0" }}>
    <div style={{ fontSize: 10, letterSpacing: ".14em", textTransform: "uppercase", fontWeight: 700, color: C.muted, marginBottom: 11 }}>{title}</div>
    {children}
  </div>
);
const Grid = ({ items }) => (
  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
    {items.map(([l, v]) => (
      <div key={l} style={{ border: `1px solid ${C.line}`, borderRadius: 12, padding: "10px 12px", display: "flex", flexDirection: "column", gap: 3 }}>
        <span style={{ fontSize: 9, color: C.muted, textTransform: "uppercase", letterSpacing: ".08em" }}>{l}</span>
        <span style={{ fontFamily: SERIF, fontSize: 22, lineHeight: 1, color: C.ink }}>{v}</span>
      </div>
    ))}
  </div>
);
const Ev = ({ a, b }) => (
  <div style={{ display: "flex", justifyContent: "space-between", gap: 10, padding: "6px 0", fontSize: 13 }}>
    <span style={{ fontWeight: 600, color: C.ink }}>{a}</span>
    <span style={{ fontSize: 11, color: C.muted, textAlign: "right" }}>{b}</span>
  </div>
);
const Empty = () => <div style={{ fontSize: 12, color: C.muted, fontStyle: "italic" }}>Inga registrerade händelser</div>;

function pill(a) {
  return { padding: "8px 18px", borderRadius: 999, border: `1px solid ${a ? C.ink : C.line}`,
    background: a ? C.ink : C.card, color: a ? "#fff" : C.ink, fontSize: 12.5, fontWeight: 600,
    cursor: "pointer", fontFamily: SANS, letterSpacing: ".03em", transition: "all .15s" };
}
function tag(t) {
  const hot = t === "HÖG";
  return { padding: "2px 9px", borderRadius: 999, fontSize: 9, letterSpacing: ".1em", fontWeight: 700,
    background: hot ? C.accentSoft : "#f0f1f5", color: hot ? C.accent : C.muted, border: `1px solid ${hot ? "#d9ddff" : C.line}` };
}
function outcomeTag(o) {
  const map = { "Genomfört": [C.accentSoft, C.accent, "#d9ddff"], "Höjt bud": ["#e8f6ef", C.green, "#c9ead9"], "Drogs tillbaka": ["#fbeaea", C.red, "#f2cccc"] };
  const [bg, col, br] = map[o] || ["#f0f1f5", C.muted, C.line];
  return { padding: "2px 9px", borderRadius: 999, fontSize: 9, letterSpacing: ".08em", fontWeight: 700, background: bg, color: col, border: `1px solid ${br}` };
}

const s = {
  nav: { display: "flex", alignItems: "center", justifyContent: "space-between", margin: "14px 14px 0", padding: "12px 16px",
    background: C.card, border: `1px solid ${C.line}`, borderRadius: 999, boxShadow: "0 6px 24px rgba(13,18,32,.05)" },
  brandDot: { width: 16, height: 16, borderRadius: "50%", background: C.accent, boxShadow: `0 0 0 4px ${C.accentSoft}` },
  eyebrow: { display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 13px", background: C.card,
    border: `1px solid ${C.line}`, borderRadius: 999, fontSize: 12, color: C.muted, fontWeight: 600, boxShadow: "0 4px 16px rgba(13,18,32,.04)" },
  h1: { fontFamily: SERIF, fontSize: 52, lineHeight: .98, fontWeight: 400, letterSpacing: "-.02em", margin: "20px 0 0", maxWidth: 360, color: C.ink },
  sub: { fontSize: 15, lineHeight: 1.5, color: C.muted, marginTop: 16, maxWidth: 340 },
  radar: { position: "absolute", top: -30, right: -46, width: 150, height: 150, opacity: .9 },
  ring: { position: "absolute", inset: 0, border: `1px solid ${C.line}`, borderRadius: "50%" },
  ring2: { position: "absolute", inset: 34, border: `1px solid ${C.line}`, borderRadius: "50%" },
  sweep: { position: "absolute", inset: 0, borderRadius: "50%", background: "conic-gradient(from 0deg, rgba(59,76,255,.16), transparent 65%)", animation: "sweep 3.4s linear infinite" },
  blip: { position: "absolute", top: 44, left: 96, width: 7, height: 7, borderRadius: "50%", background: C.accent, boxShadow: `0 0 0 4px ${C.accentSoft}`, animation: "blink 1.7s infinite" },
  filterRow: { display: "flex", gap: 8, padding: "6px 20px 12px" },
  co: { textAlign: "left", background: C.card, border: `1px solid ${C.line}`, borderRadius: 18, padding: "16px 16px 14px", cursor: "pointer", fontFamily: SANS, boxShadow: "0 8px 30px rgba(13,18,32,.05)" },
  rank: { fontSize: 12, fontWeight: 700, color: C.muted, fontVariantNumeric: "tabular-nums", width: 22 },
  meta: { fontSize: 11.5, color: C.muted, marginTop: 2 },
  track: { height: 5, borderRadius: 999, background: "#eceef4", overflow: "hidden" },
  fill: { height: "100%", borderRadius: 999, transition: "width .9s cubic-bezier(.2,.8,.2,1)" },
  sparkL: { fontSize: 9, color: C.muted, marginTop: 5, letterSpacing: ".04em", textAlign: "center" },
  infoBox: { background: C.accentSoft, border: `1px solid #d9ddff`, borderRadius: 14, padding: "14px 16px", fontSize: 13, lineHeight: 1.55, color: C.muted },
  bidcoHint: { marginTop: 18, background: C.card, border: `1px solid ${C.line}`, borderRadius: 14, padding: "13px 15px", fontSize: 12.5, lineHeight: 1.55, color: C.muted, boxShadow: "0 4px 16px rgba(13,18,32,.04)" },
  search: { width: "100%", padding: "11px 36px 11px 14px", borderRadius: 999, border: `1px solid ${C.line}`,
    background: C.card, fontSize: 14, fontFamily: SANS, color: C.ink, outline: "none",
    boxShadow: "0 4px 16px rgba(13,18,32,.04)" },
  searchClear: { position: "absolute", right: 30, top: "50%", transform: "translateY(-50%)",
    background: "none", border: "none", fontSize: 20, color: C.muted, cursor: "pointer",
    lineHeight: 1, padding: 0, fontFamily: SANS },
  linkBtn: { background: "none", border: "none", color: C.accent, fontWeight: 700, cursor: "pointer", fontFamily: SANS, fontSize: 13, padding: 0 },
  signalTag: { display: "inline-block", background: C.accentSoft, color: C.accent, border: "1px solid #d9ddff", borderRadius: 999, padding: "3px 11px", fontSize: 10.5, fontWeight: 700, letterSpacing: ".03em" },
  chipOffer: { background: C.accent, color: "#fff", borderRadius: 999, padding: "2px 9px", fontSize: 9, letterSpacing: ".12em", fontWeight: 700, flexShrink: 0 },
  overlay: { position: "fixed", inset: 0, background: "rgba(13,18,32,.35)", backdropFilter: "blur(2px)", zIndex: 50, display: "flex", alignItems: "flex-end", justifyContent: "center" },
  sheet: { background: C.card, width: "100%", maxWidth: 480, maxHeight: "90vh", overflowY: "auto", borderRadius: "24px 24px 0 0", padding: "10px 20px 26px", animation: "slideUp .32s cubic-bezier(.2,.8,.2,1)", boxShadow: "0 -10px 50px rgba(13,18,32,.2)" },
  grip: { width: 42, height: 5, background: C.line, borderRadius: 3, margin: "6px auto 16px" },
  sheetHead: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 16, borderBottom: `1px solid ${C.line}`, marginBottom: 4 },
  closeBtn: { width: "100%", marginTop: 18, padding: "14px", background: C.ink, color: "#fff", border: "none", borderRadius: 999, fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: SANS, transition: "transform .15s" },
  foot: { fontSize: 10.5, color: C.muted, padding: "22px 24px 0", lineHeight: 1.6, textAlign: "center" },
  bottomWrap: { position: "fixed", bottom: 0, left: 0, right: 0, display: "flex", justifyContent: "center", padding: "0 14px 14px", pointerEvents: "none" },
  bottomNav: { pointerEvents: "auto", width: "100%", maxWidth: 452, display: "flex", background: C.card, border: `1px solid ${C.line}`,
    borderRadius: 22, padding: "8px 8px", boxShadow: "0 10px 40px rgba(13,18,32,.14)" },
};

const CSS = `
  @keyframes sweep { to { transform: rotate(360deg); } }
  @keyframes blink { 0%,100% { opacity:1;} 50% { opacity:.25;} }
  @keyframes slideUp { from { transform: translateY(100%);} to { transform: translateY(0);} }
  @keyframes fadein { from { opacity: 0; transform: translateY(12px);} to { opacity: 1; transform: translateY(0);} }
  .fadein { animation: fadein .35s cubic-bezier(.2,.8,.2,1) both; }
  .card:active { transform: translateY(1px) scale(.995) !important; }
  .pill:active { transform: scale(.96); }
  .book:hover { transform: translateY(-1px); }
  .acc:active { opacity:.7; }
  @media (prefers-reduced-motion: reduce) { * { animation: none !important; } }
`;

ReactDOM.createRoot(document.getElementById("root")).render(<BudRadar />);
