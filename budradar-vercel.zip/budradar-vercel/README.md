# BudRadar — så får du den live (utan terminal)

Det här är hela appen i **ett** projekt: själva appen (`index.html`) och
datahämtaren (`api/companies.js`) i samma mapp. Du behöver inte installera
något på din dator. Allt körs i molnet på Vercel.

## Vad du gör (ca 10 min, allt i webbläsaren)

### 1. Skapa konton (gratis)
- **github.com** — skapa konto
- **vercel.com** — klicka "Sign up", välj "Continue with GitHub"

### 2. Lägg upp koden på GitHub
1. På github.com, klicka gröna **New** (nytt repository).
2. Döp det till `budradar`, välj **Public**, klicka **Create repository**.
3. På nästa sida, klicka länken **"uploading an existing file"**.
4. Dra in **alla filer från den uppackade mappen** här:
   - `index.html`
   - `package.json`
   - hela mappen `api` (med `companies.js` i)
   > Viktigt: behåll `companies.js` inuti en mapp som heter `api`.
   > Enklast: dra in `index.html` och `package.json` först, och skapa sedan
   > `api/companies.js` genom att skriva `api/companies.js` som filnamn när du
   > klistrar in innehållet (GitHub skapar mappen automatiskt).
5. Klicka **Commit changes**.

### 3. Deploya på Vercel
1. På vercel.com → **Add New… → Project**.
2. Välj ditt `budradar`-repo → **Import**.
3. Rör inga inställningar. Klicka **Deploy**.
4. Vänta ~1 min. Du får en URL, t.ex. `https://budradar.vercel.app`.

Öppna URL:en i mobilen → du har din egen BudRadar. 🎉

## Vad statuschipet betyder
- **● LIVE** — riktig data hämtades från FI/MFN. ✅
- **DEMODATA** — datahämtaren nådde inte källorna (se nedan).

## Om det står DEMODATA (felsökning)
Datahämtaren funkar, men en käll-URL kan behöva justeras. Öppna
`api/companies.js` på GitHub (klicka filen → pennan för att redigera) och
kolla de tre URL:erna högst upp:
- `INSIDER_CSV` — FI:s insynsregister-export
- `SHORT_URL` — FI:s blankningslista
- `MFN_FEED` — MFN:s flaggningsflöde

Öppna var och en i en webbläsarflik. Får du data (text/CSV/JSON) är URL:en rätt.
Får du fel — gå till källans sida, hitta rätt nedladdnings-/export-länk, och
klistra in den. När du sparar på GitHub bygger Vercel om automatiskt på nån minut.

Tips: testa endpointet direkt genom att öppna `https://din-app.vercel.app/api/companies`
i webbläsaren — då ser du rådata och vilken källa som lyckades/misslyckades
(`fetched`-fältet visar status per källa).

## Bra att veta
- Datan cachas 30 min (snällt mot FI som begränsar antal sökningar).
- Bolagsverket/POIT är inte med i denna enkla version (kräver scraping som
  passar bättre i den separata backend-varianten).
- Detta aggregerar endast offentlig data. Ej investeringsrådgivning. Scoren är
  en transparent viktad summa, inte en backtestad sannolikhet.
